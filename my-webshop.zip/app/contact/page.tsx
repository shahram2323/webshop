
export default function Contact() {
  return (
    <form className='grid gap-2'>
      <input placeholder='Your Name' className='border p-2' />
      <input placeholder='Your Email' className='border p-2' />
      <textarea placeholder='Your Message' className='border p-2' />
      <button className='bg-purple-500 text-white p-2'>Send</button>
    </form>
  );
}
