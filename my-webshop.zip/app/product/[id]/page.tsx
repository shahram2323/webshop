
export default function ProductDetail() {
  return (
    <div>
      <h1 className='text-2xl font-bold'>Rainbow Shirt</h1>
      <p>$29</p>
      <p>Colorful and comfy.</p>
      <img src='https://via.placeholder.com/600x400' alt='product image' />
    </div>
  );
}
