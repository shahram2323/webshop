
import Link from 'next/link';
export default function Layout({ children }) {
  return (
    <div className='p-4'>
      <nav className='space-x-4 text-blue-600'>
        <Link href='/'>Home</Link>
        <Link href='/shop'>Shop</Link>
        <Link href='/cart'>Cart</Link>
        <Link href='/checkout'>Checkout</Link>
        <Link href='/login'>Login</Link>
        <Link href='/contact'>Contact</Link>
      </nav>
      <main className='mt-4'>{children}</main>
    </div>
  );
}
