
export default function Login() {
  return (
    <div className='grid gap-2'>
      <input placeholder='Email' className='border p-2' />
      <input type='password' placeholder='Password' className='border p-2' />
      <button className='bg-blue-500 text-white p-2'>Login</button>
    </div>
  );
}
