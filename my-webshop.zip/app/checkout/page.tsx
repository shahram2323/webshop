
export default function Checkout() {
  return (
    <form className='grid gap-2'>
      <input placeholder='Name' className='border p-2' />
      <input placeholder='Email' className='border p-2' />
      <input placeholder='Card Number' className='border p-2' />
      <button className='bg-green-500 text-white p-2'>Pay Now</button>
    </form>
  );
}
