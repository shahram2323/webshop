
import Link from 'next/link';
export default function Shop() {
  return (
    <div className='grid gap-4'>
      <Link href='/product/1'>Rainbow Shirt - $29</Link>
      <Link href='/product/2'>Magic Mug - $15</Link>
      <Link href='/product/3'>Sparkle Shoes - $49</Link>
    </div>
  );
}
